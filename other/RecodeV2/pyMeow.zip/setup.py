from setuptools import setup

setup(
   name='pyMeow',
   version='1.27.15',
   description='Python Library for external Game Hacking',
   author='qb',
   packages=['pyMeow'],
   include_package_data=True,
   url='https://github.com/qb-0/PyMeow.',
   license='MIT'
)